// src/context/SettingsContext.jsx
//
// Stratégie de synchronisation :
//  1. Au montage          → charge depuis localStorage (instantané, hors ligne)
//  2. Après login         → charge depuis le serveur, écrase localStorage
//  3. À chaque changement → sauvegarde dans localStorage (immédiat)
//                        → debounce 800ms → sauvegarde sur le serveur si connecté
//  4. Au logout           → nettoie le localStorage de l'utilisateur courant
//
import React, { createContext, useContext, useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../firebase';
import { getPreferences, savePreferences } from '../api/authService';
import { useAppConfigOptional } from './AppConfigContext';
import { applyPolicy, canChoose, policyDefaults, readCachedPolicy } from '../utils/appConfig';

const SettingsContext = createContext(null);

export const useSettings = () => {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings doit être utilisé dans <SettingsProvider>');
  return ctx;
};

// ── Constantes ────────────────────────────────────────────────────

const DEFAULTS = {
  difficulty:         'medium',
  gameLanguage:       'fr',        // langue des parties solo (dictionnaire, sac, valeurs)
  turnDuration:       0,
  showScorePreview:   true,
  showRemainingTiles: true,
  showBonusLabels:    true,
  autoSortRack:       false,
  confirmValidation:  false,
  boardSize:          'normal',
  animationsEnabled:  true,
  language:           'fr',
  tutorialSeen:       false,
  // Notifications push (lot 7) : catégories reçues (l'activation se fait par appareil)
  pushInvites:        true,
  pushFriends:        true,
  pushMessages:       true,
  pushTurn:           true,
};

const TURN_OPTIONS = [
  { value: 0,   label: 'Illimité',  short: '∞'    },
  { value: 60,  label: '1 minute',  short: '1 min' },
  { value: 120, label: '2 minutes', short: '2 min' },
  { value: 180, label: '3 minutes', short: '3 min' },
  { value: 300, label: '5 minutes', short: '5 min' },
];

const DIFFICULTY_META = {
    beginner:   { label: 'Débutant',  emoji: '🐣', desc: "Mots très courts, beaucoup d'erreurs",     color: 'var(--text-muted)' },
    easy:       { label: 'Facile',    emoji: '🟢', desc: 'Mots courts, ignore les cases bonus',       color: 'var(--olive)'     },
    medium:     { label: 'Moyen',     emoji: '🟡', desc: 'Équilibré, utilise quelques bonus',          color: 'var(--gold)'      },
    hard_minus: { label: 'Difficile', emoji: '🟠', desc: "Mots longs, tous les bonus, peu d'erreurs", color: 'var(--tobacco)'   },
    hard:       { label: 'Expert',    emoji: '🔴', desc: 'Maximise chaque score, tous les bonus',      color: 'var(--brick)'     },
};

// ── Clé localStorage par utilisateur ─────────────────────────────

function storageKey(uid) {
  return uid ? `scrabble-settings-${uid}` : 'scrabble-settings-guest';
}

// Appareil sans réglages enregistrés : défauts de l'administrateur (lot A2)
const freshDefaults = () => ({ ...DEFAULTS, ...policyDefaults(readCachedPolicy()) });

function loadFromStorage(uid) {
  try {
    const raw = localStorage.getItem(storageKey(uid));
    if (!raw) return freshDefaults();
    return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    return freshDefaults();
  }
}

function persistToStorage(uid, settings) {
  try {
    localStorage.setItem(storageKey(uid), JSON.stringify(settings));
  } catch { /* stockage indisponible (navigation privée, quota) : on continue sans */ }
}

function clearGuestStorage() {
  try {
    localStorage.removeItem('scrabble-settings-guest');
  } catch { /* stockage indisponible (navigation privée, quota) : on continue sans */ }
}

// ── Provider ──────────────────────────────────────────────────────

export function SettingsProvider({ children }) {
  const [currentUid, setCurrentUid] = useState(null);
  const [rawSettings, setSettings]  = useState(() => loadFromStorage(null));
  // Lot A2 : réglages verrouillés / masqués et options retirées par l'administrateur
  const policy = useAppConfigOptional()?.policy ?? null;
  const settings = useMemo(() => applyPolicy(policy, rawSettings), [policy, rawSettings]);
  const [syncing, setSyncing]        = useState(false);
  const [lastSynced, setLastSynced]  = useState(null);
  // uid dont les préférences serveur viennent d'être chargées (ThemeContext
  // s'en sert pour appliquer le thème du compte une fois par connexion)
  const [serverLoadedFor, setServerLoadedFor] = useState(null);
  const debounceRef = useRef(null);

  // ── Observer Firebase auth — indépendant d'AuthContext ───────────
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const uid = firebaseUser.uid;
        setCurrentUid(uid);

        // 1. Charger préférences locales (immédiat, pas de flash)
        const local = loadFromStorage(uid);
        setSettings(local);

        // 2. Charger depuis le serveur (peut prendre quelques ms)
        try {
          const serverPrefs = await getPreferences();
          const merged = { ...DEFAULTS, ...serverPrefs };
          setSettings(merged);
          persistToStorage(uid, merged);
          setLastSynced(new Date());
          setServerLoadedFor(uid);
        } catch (err) {
          console.warn('Préférences serveur indisponibles, cache local utilisé:', err.message);
        }

        // 3. Nettoyer les préférences invité
        clearGuestStorage();
      } else {
        // Logout
        setCurrentUid(null);
        setLastSynced(null);
        setServerLoadedFor(null);
        setSettings(loadFromStorage(null));
      }
    });

    return unsubscribe;
  }, []);

  // ── Persistance locale à chaque changement ────────────────────
  useEffect(() => {
    persistToStorage(currentUid, rawSettings);
  }, [rawSettings, currentUid]);

  // ── Sync serveur debounced ────────────────────────────────────
  // Les changements rapprochés sont cumulés : un seul envoi, rien de perdu
  const pendingRef = useRef({});
  const syncToServer = useCallback((patch) => {
    if (!currentUid) return;
    pendingRef.current = { ...pendingRef.current, ...patch };
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      const toSend = pendingRef.current;
      pendingRef.current = {};
      setSyncing(true);
      try {
        await savePreferences(toSend);
        setLastSynced(new Date());
      } catch (err) {
        console.warn('Sync préférences échouée:', err.message);
      } finally {
        setSyncing(false);
      }
    }, 800);
  }, [currentUid]);

  // Un réglage fixé par l'administrateur, ou une option retirée, n'est pas modifiable
  const allowedPatch = useCallback((patch) => Object.fromEntries(
    Object.entries(patch).filter(([k, v]) => canChoose(policy, k, v)),
  ), [policy]);

  const update = useCallback((key, value) => {
    const patch = allowedPatch({ [key]: value });
    if (!(key in patch)) return;
    setSettings(prev => ({ ...prev, ...patch }));
    syncToServer(patch);
  }, [syncToServer, allowedPatch]);

  const updateMany = useCallback((patch) => {
    const allowed = allowedPatch(patch);
    setSettings(prev => ({ ...prev, ...allowed }));
    syncToServer(allowed);
  }, [syncToServer, allowedPatch]);

  const reset = useCallback(() => {
    const defaults = allowedPatch({ ...DEFAULTS, ...policyDefaults(policy) });
    setSettings(prev => ({ ...prev, ...defaults }));
    syncToServer(defaults);
  }, [syncToServer, allowedPatch, policy]);

  return (
    <SettingsContext.Provider value={{
      settings,
      update,
      updateMany,
      reset,
      syncing,
      lastSynced,
      currentUid,
      serverLoadedFor,
      TURN_OPTIONS,
      DIFFICULTY_META,
    }}>
      {children}
    </SettingsContext.Provider>
  );
}

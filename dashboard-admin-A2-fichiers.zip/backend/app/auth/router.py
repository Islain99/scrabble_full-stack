# app/auth/router.py

import time
import logging
from collections import defaultdict
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, field_validator

from app.core.firebase import verify_firebase_token
from app.db.database import get_db
from app.db.models import User
from app.auth.dependencies import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Authentification"])
bearer_scheme = HTTPBearer(auto_error=True)


# ── Rate limiter en mémoire ────────────────────────────────────────
# Fenêtre glissante par IP. Sans dépendance externe.
# Convient pour Railway single-worker.
# Pour multi-workers → remplacer par Redis + slowapi.

class _SlidingWindowLimiter:
    def __init__(self, max_calls: int, window_seconds: int):
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self._timestamps: dict[str, list[float]] = defaultdict(list)

    def is_allowed(self, key: str) -> bool:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        # Purge des appels hors fenêtre
        self._timestamps[key] = [t for t in self._timestamps[key] if t > cutoff]
        if len(self._timestamps[key]) >= self.max_calls:
            return False
        self._timestamps[key].append(now)
        return True


# 10 appels / minute par IP sur /register et /login
_auth_limiter = _SlidingWindowLimiter(max_calls=10, window_seconds=60)


def _get_client_ip(request: Request) -> str:
    """Extrait l'IP réelle en tenant compte des proxies Railway/Vercel."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _check_rate_limit(request: Request) -> None:
    """
    Dépendance FastAPI. Déclarée AVANT bearer_scheme et get_db dans les
    routes : un appel bloqué n'ouvre ni vérification de token ni session DB.
    """
    ip = _get_client_ip(request)
    if not _auth_limiter.is_allowed(ip):
        logger.warning("Rate limit atteint ip=%s", ip)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Trop de tentatives. Réessayez dans une minute.",
            headers={"Retry-After": "60"},
        )


# ── Schemas ────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    display_name: str

    @field_validator("display_name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 2:
            raise ValueError("Le pseudo doit contenir au moins 2 caractères.")
        if len(v) > 32:
            raise ValueError("Le pseudo ne peut pas dépasser 32 caractères.")
        return v


class UserOut(BaseModel):
    id: int
    firebase_uid: str
    email: str
    display_name: str
    first_name: str | None
    last_name: str | None
    age: int | None
    country: str | None
    avatar_url: str | None
    bio: str | None
    auth_provider: str
    is_verified: bool
    profile_complete: bool
    games_played: int
    games_won: int
    total_score: int
    best_score: int
    best_word: str | None
    best_word_score: int
    average_score: float
    win_rate: float
    is_admin: bool = False      # messagerie : modération du salon universel
    # Multijoueur (lot 7) : statistiques séparées et cote Elo
    mp_rating: int = 1200
    mp_peak_rating: int = 1200
    mp_games: int = 0
    mp_wins: int = 0
    mp_draws: int = 0
    mp_best_score: int = 0
    mp_win_rate: float = 0.0
    # Confidentialité (lot 8) : mes réglages « qui voit quoi »
    privacy: dict = {}
    created_at: datetime
    last_login_at: datetime

    class Config:
        from_attributes = True

    @classmethod
    def from_user(cls, user: "User") -> "UserOut":
        return cls(
            id=user.id,
            firebase_uid=user.firebase_uid,
            email=user.email,
            display_name=user.display_name,
            first_name=user.first_name,
            last_name=user.last_name,
            age=user.age,
            country=user.country,
            avatar_url=user.avatar_url,
            bio=user.bio,
            auth_provider=user.auth_provider,
            is_verified=user.is_verified,
            profile_complete=user.profile_complete,
            games_played=user.games_played,
            games_won=user.games_won,
            total_score=user.total_score,
            best_score=user.best_score,
            best_word=user.best_word,
            best_word_score=user.best_word_score,
            average_score=user.average_score,
            win_rate=user.win_rate,
            is_admin=bool(getattr(user, "is_admin", False)),
            mp_rating=user.mp_rating or 1200,
            mp_peak_rating=user.mp_peak_rating or 1200,
            mp_games=user.mp_games or 0,
            mp_wins=user.mp_wins or 0,
            mp_draws=user.mp_draws or 0,
            mp_best_score=user.mp_best_score or 0,
            mp_win_rate=user.mp_win_rate,
            privacy=_privacy_of(user),
            created_at=user.created_at,
            last_login_at=user.last_login_at,
        )


def _privacy_of(user) -> dict:
    from app.users.privacy import settings_of        # import tardif : pas de cycle
    return settings_of(user).model_dump()


def _promote_if_listed(user: User) -> None:
    """Dashboard admin : l'e-mail figure dans ADMIN_EMAILS → administrateur."""
    from app.core.config import get_settings
    if not user.is_admin and (user.email or "").lower() in get_settings().admin_emails:
        user.is_admin = True
        logger.info("Utilisateur %s promu administrateur (ADMIN_EMAILS).", user.firebase_uid)


async def _apply_privacy_defaults(db: AsyncSession, user: User) -> None:
    """Lot A2 : un nouveau compte reçoit les défauts de confidentialité de l'administrateur."""
    from app.appconfig.catalog import privacy_defaults
    from app.appconfig.service import get_policy
    for column, value in privacy_defaults(await get_policy(db)).items():
        setattr(user, column, value)


class LoginResponse(BaseModel):
    user: UserOut
    is_new_user: bool


# ── Routes ─────────────────────────────────────────────────────────

@router.post("/register", response_model=LoginResponse, status_code=status.HTTP_201_CREATED)
async def register(
    payload: RegisterRequest,
    _rl: None = Depends(_check_rate_limit),  # en premier : avant token et DB
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
):
    try:
        decoded = verify_firebase_token(credentials.credentials)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token Firebase invalide.")

    firebase_uid = decoded["uid"]
    email = decoded.get("email", "")
    provider = decoded.get("firebase", {}).get("sign_in_provider", "email")
    avatar_url = decoded.get("picture")
    email_verified = decoded.get("email_verified", False)

    result = await db.execute(select(User).where(User.firebase_uid == firebase_uid))
    existing = result.scalar_one_or_none()
    if existing:
        existing.last_login_at = datetime.now(timezone.utc)
        _promote_if_listed(existing)
        return LoginResponse(user=UserOut.from_user(existing), is_new_user=False)

    result = await db.execute(select(User).where(User.email == email))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Un compte avec cet email existe déjà.")

    user = User(
        firebase_uid=firebase_uid,
        email=email,
        display_name=payload.display_name,
        avatar_url=avatar_url,
        auth_provider=provider,
        is_verified=email_verified,
        is_admin=False,
    )
    _promote_if_listed(user)
    await _apply_privacy_defaults(db, user)
    db.add(user)
    await db.flush()
    await db.refresh(user)
    logger.info("Nouvel utilisateur : uid=%s provider=%s", firebase_uid, provider)
    return LoginResponse(user=UserOut.from_user(user), is_new_user=True)


@router.post("/login", response_model=LoginResponse)
async def login(
    _rl: None = Depends(_check_rate_limit),  # en premier : avant token et DB
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
):
    try:
        decoded = verify_firebase_token(credentials.credentials)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token invalide.")

    firebase_uid = decoded["uid"]
    email = decoded.get("email", "")
    provider = decoded.get("firebase", {}).get("sign_in_provider", "email")
    avatar_url = decoded.get("picture")
    email_verified = decoded.get("email_verified", False)

    result = await db.execute(select(User).where(User.firebase_uid == firebase_uid))
    user = result.scalar_one_or_none()

    if user:
        user.last_login_at = datetime.now(timezone.utc)
        _promote_if_listed(user)
        return LoginResponse(user=UserOut.from_user(user), is_new_user=False)

    result = await db.execute(select(User).where(User.email == email))
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Un compte avec cet email existe déjà (autre méthode).",
        )

    display_name = decoded.get("name") or email.split("@")[0]
    user = User(
        firebase_uid=firebase_uid,
        email=email,
        display_name=display_name,
        avatar_url=avatar_url,
        auth_provider=provider,
        is_verified=email_verified,
        is_admin=False,
    )
    _promote_if_listed(user)
    await _apply_privacy_defaults(db, user)
    db.add(user)
    await db.flush()
    await db.refresh(user)
    logger.info("Connexion auto-création : uid=%s provider=%s", firebase_uid, provider)
    return LoginResponse(user=UserOut.from_user(user), is_new_user=True)


@router.get("/me", response_model=UserOut)
async def me(current_user: User = Depends(get_current_user)):
    return UserOut.from_user(current_user)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(current_user: User = Depends(get_current_user)):
    """Logout côté serveur — la révocation Firebase est gérée côté client."""
    logger.info("Logout : user_id=%s", current_user.id)